---
name: progress-check
description: >
  Use when the user asks "where are we?", "what's the status?", or "/progress".
  This skill reads meeting-progress.md and the Master Library files in the student's
  repo, then displays a structured status table — which meetings are completed,
  what's next, and which knowledge files have been built. Hebrew triggers:
  "איפה אנחנו", "מה הסטטוס", "מה הספקנו", "תראה לי את ההתקדמות", "סטטוס".
version: 1.0.0
---

# Progress Check — בדיקת סטטוס

> סקיל קריאה בלבד. **לא מקדם את התהליך.** רק מציג איפה התלמיד עומד.

---

## קלט

הסקיל מצפה לרוץ ב-context שיש בו גישה לקבצים של ה-repo של התלמיד.

הוא קורא:
1. `meeting-progress.md` (חובה — אם לא קיים, מציג הודעה מתאימה)
2. כל `meeting-NN-decisions.md` ב-repo
3. תוכן `Master Library/` (או `ספריית מאסטר/`) ב-שורש
4. תוכן `סוכנים/בפיתוח/[שם-Agent-2]/` (אם קיים)

---

## לוגיקה

### שלב 1: בדיקת קיום `meeting-progress.md`

**אם הקובץ לא קיים:**

הצג:
```
**סטטוס: טרם התחלנו.**

לא נמצא `meeting-progress.md` ב-repo. כנראה שעוד לא יצרנו אותו.

כדי להתחיל, תריץ/י `/bnaya` — זה יפתח את מפגש 1: הקמת סביבת עבודה.
```

**עצור כאן.**

### שלב 2: קריאת מצב נוכחי

קרא את `meeting-progress.md`. חלץ:
- מפגש אחרון שהושלם
- מפגש הבא
- סטטוס נוכחי
- שם Agent 2
- שפת עבודה
- מע' הפעלה
- רשימת מסמכי ידע שנבנו

### שלב 3: סריקת קבצים בפועל

בדוק אילו קבצים *באמת* קיימים ב-`Master Library/` של ה-repo (השורש):
- `knowledge-about-me.md`
- `knowledge-about-audience.md` (אופציונלי)
- `starting-point.md`
- `technical-context.md`
- `tools-and-environment.md`
- `built-assets.md`
- `goals-and-use-cases.md`
- `business-operations.md` (אופציונלי)
- `offerings.md` (אופציונלי)

בדוק אם קיימים:
- `סוכנים/בפיתוח/[שם]/system-prompt.md`
- `סוכנים/בפיתוח/[שם]/.claude-plugin/plugin.json`
- `סוכנים/בפיתוח/[שם]/Master Library/course-overview.md`
- `סוכנים/בפיתוח/[שם]/Master Library/aimprove-methods.md`
- `סוכנים/בפיתוח/[שם]/Master Library/course-tools.md`
- `סוכנים/בפיתוח/[שם]/Master Library/course-lessons.md`
- `סוכנים/בפיתוח/[שם]/Master Library/course-projects.md`

### שלב 4: סריקת מסמכי החלטות

ספור כמה `meeting-NN-decisions.md` קיימים. אלה המפגשים שהושלמו פורמלית.

---

## פלט — פורמט מובנה

הצג את הסטטוס בפורמט הזה:

```
## סטטוס: [סוף מפגש N / מפגש N — בעיצומו / הושלם — Agent 2 חי]

### הגדרות תלמיד
- **שם Agent 2:** [שם]
- **שפת עבודה:** [עברית / English]
- **מע' הפעלה:** [Mac / Windows / Linux]

### מפגשים

| # | מפגש | סטטוס | תוצרים |
|---|-------|--------|---------|
| 1 | הקמת סביבת עבודה | ✅ הושלם / 🔄 בעיצומו / ⏳ ממתין | repo, מבנה, שמות |
| 2 | מיפוי עסק וקהל | ✅ / 🔄 / ⏳ | knowledge-about-me [+ audience] |
| 3 | המצב שלך עם AI | ✅ / 🔄 / ⏳ | starting-point |
| 4 | סביבה טכנית | ✅ / 🔄 / ⏳ | technical-context, tools-and-environment |
| 5 | מה כבר בנית | ✅ / 🔄 / ⏳ | built-assets |
| 6 | מיפוי רעיונות | ✅ / 🔄 / ⏳ | goals-and-use-cases |
| 7 | כתיבת המוח | ✅ / 🔄 / ⏳ | system-prompt + course-overview + placeholders |
| 8 | הרכבה ומבחן | ✅ / 🔄 / ⏳ | Plugin + Project + דמו |

### מסמכי ידע ב-Master Library

| מסמך | קיים | מפגש |
|------|------|------|
| knowledge-about-me.md | ✅ / ⏳ | 2 |
| knowledge-about-audience.md (אופציונלי) | ✅ / ⏳ / N/A | 2 |
| starting-point.md | ✅ / ⏳ | 3 |
| technical-context.md | ✅ / ⏳ | 4 |
| tools-and-environment.md | ✅ / ⏳ | 4 |
| built-assets.md | ✅ / ⏳ | 5 |
| goals-and-use-cases.md | ✅ / ⏳ | 6 |

### Agent 2 (`סוכנים/בפיתוח/[שם]/`)

| קובץ | קיים |
|------|------|
| system-prompt.md | ✅ / ⏳ |
| .claude-plugin/plugin.json | ✅ / ⏳ |
| Master Library/course-overview.md | ✅ / ⏳ |
| Master Library/aimprove-methods.md | ✅ / ⏳ |
| Master Library/course-tools.md (placeholder) | ✅ / ⏳ |
| Master Library/course-lessons.md (placeholder) | ✅ / ⏳ |
| Master Library/course-projects.md (placeholder) | ✅ / ⏳ |

### מה הבא

[משפט אחד על מה המפגש הבא — ושמירה על הטון של בְּנָיָה]

---

לחץ/י `/bnaya` כדי להמשיך.
```

---

## טיפול במקרי קצה

### אם יש סתירה בין `meeting-progress.md` לקבצים בפועל

לדוגמה: `meeting-progress.md` אומר "סוף מפגש 4" אבל `technical-context.md` חסר.

הצג אזהרה:
```
⚠️ זוהתה סתירה: לפי `meeting-progress.md` סיימנו את מפגש N, אבל קובץ `[X]` חסר.

אפשרויות:
1. אולי הקובץ נמחק בטעות — בדוק/י ב-Git history
2. אולי הקובץ קיים אבל במקום אחר — חפש/י בכל ה-repo
3. אם זה תקין — עדכן/י את `meeting-progress.md` כדי לשקף את המציאות
```

### אם המסע הושלם

אם `meeting-progress.md` מציין "הושלם":
```
## ✅ סיימנו! Agent 2 חי ועובד.

המסע הושלם ב-[תאריך מ-meeting-08-decisions.md].

**מה יש לך:**
- Repository ב-GitHub עם 8 commits של pre-work
- 9-12 מסמכי ידע מקיפים
- Agent 2 פעיל ב-Claude Project
- 8 מסמכי החלטות

**מה הלאה:**
- ביום 1 של הקורס — את/ה מגיע/ה עם סוכן שמכיר אותך
- אחרי כל שיעור — תזין/י חומרים ל-Agent 2
- כשתערוך/תערכי קובץ ידע — תפעיל/י `/sync`

בהצלחה במסע. בְּנָיָה איתך.
```

### אם נמצא רק `meeting-progress.md` בלי `meeting-NN-decisions.md` תואמים

הצג אזהרה:
```
⚠️ `meeting-progress.md` קיים אבל אין מסמכי החלטות. אולי לא נדחפו ל-Git?

הצעה: תעשה/תעשי commit+push ולאחר מכן `/progress` שוב.
```

---

## עיקרון

הסקיל הזה הוא **ראי** — מציג את המציאות. הוא לא משנה כלום, לא יוצר קבצים, לא מקדם את המסע.

**מה הוא כן עושה:** מאפשר לתלמיד לראות את המסע מלמעלה — מה הספיק, מה נותר, איפה אנחנו.

**מה הוא לא:** הוא לא מתחיל מפגש. כדי להתחיל מפגש — `/bnaya`.
